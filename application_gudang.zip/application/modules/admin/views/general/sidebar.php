<div class="page-container">
  <!-- BEGIN SIDEBAR -->
  <!-- <div class="page-sidebar-wrapper">
    <div class="page-sidebar navbar-collapse collapse">
      <ul class="page-sidebar-menu page-sidebar-menu-hover-submenu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
        <li class="start active ">
          <a href="<?php echo base_url() . 'admin/' ?>">
            <i class="icon-home"></i>
            <span class="title">Dashboard</span>
            <span class="selected"></span>

          </a>
        </li>
         <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'master' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Master</span>


          </a>
        </li>
        

        <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'pembelian/daftar_pembelian' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Pembelian</span>


          </a>
        </li>
        <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'retur_pembelian' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Retur Pembelian</span>


          </a>
        </li>
<li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'stok/daftar_stok' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Stok</span>


          </a>
        </li>
<li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'spoil/daftar_spoil/' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Spoil</span>


          </a>
        </li>
<li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'opname/daftar_opname/' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Opname</span>


          </a>
        </li>
<li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'mutasi/daftar_mutasi' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Mutasi</span>
          </a>
        </li>
<li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'validasi_request_order/daftar' ?>">
            <i class="icon-rocket"></i>
            <span class="title">Validasi Request Order</span>


          </a>
        </li>


      </ul>

    </div>
  </div> -->