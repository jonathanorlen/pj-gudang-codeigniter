<div class="">
  <div class="page-content">
 <a style="padding:13px; margin-bottom:10px" class="btn btn-app green" href="<?php echo base_url().'pre_order/pendaftaran'; ?>">
              <i class="fa fa-plus"></i> Tambah PO
            </a>
            
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app blue" href="<?php echo base_url().'pre_order/daftar'; ?>">
              <i class="fa fa-list"></i> Daftar PO
            </a>

 <div id="box_load">
<?php echo @$konten; ?></div>
</div>
</div>

