<div class="row">      

  <div class="col-xs-12">
    <!-- /.box -->
    <div class="portlet box blue">
      <div class="portlet-title">
        <div class="caption">
          Tambah Transaksi Repack
        </div>
        <div class="tools">
          <a href="javascript:;" class="collapse">
          </a>
          <a href="javascript:;" class="reload">
          </a>

        </div>
      </div>
      <div class="portlet-body">
        <!------------------------------------------------------------------------------------------------------>
        <div class="box-body">
          <div class="sukses" ></div>
          <div class="row">
            <form id="form_repack">
              <div class="col-md-6">
                <div class="form-group">
                  <label>Kode Repack</label>
                  <input readonly="" type="text" class="form-control" value="<?php echo 'RPACK_'.date('ymdhis') ?>" name="kode" id="kode" required />
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Tanggal Repack</label>
                  <input type="date" class="form-control" value="" name="tanggal_repack" id="tanggal_repack" required />
                </div>
              </div>
              <?php 
              $session = $this->session->userdata('astrosession');
              //print_r($session);
              ?>
              <div class="col-md-12">
                <div class="cek_stok" ></div>
              </div>
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-2">
                    <label>Produk</label>
                    <select id="produk" name="produk" class="form-control select2">
                      <option value="">-- PILIH --</option>
                      <?php 
                      $get_bahan = $this->db->get('master_bahan_baku');
                      $hasil_menu = $get_bahan->result();
                      foreach($hasil_menu as $daftar){
                        ?>
                        <option value="<?php echo $daftar->kode_bahan_baku; ?>"><?php echo $daftar->nama_bahan_baku; ?></option>
                        <?php 
                      } ?>
                    </select>
                  </div>
                  <div class="col-md-2">
                    <label>Produk Repack</label>
                    <select id="produk_repack" name="produk_repack" class="form-control select2">
                      <option value="">-- PILIH --</option>
                      <?php 
                      foreach($hasil_menu as $daftar){
                        ?>
                        <option value="<?php echo $daftar->kode_bahan_baku; ?>"><?php echo $daftar->nama_bahan_baku; ?></option>
                        <?php 
                      } ?>
                    </select>
                  </div>
                  <div class="col-md-2">
                    <label>Satuan Repack</label>
                    <input readonly="" type="text" class="form-control" value="" name="sat_repack" id="sat_repack" placeholder="Satuan Repack" />
                    <input readonly="" type="hidden" class="form-control" value="" name="jumlah_dalam_satuan_pembelian" id="jumlah_dalam_satuan_pembelian" placeholder="Satuan Repack" />
                    <input readonly="" type="hidden" class="form-control" value="" name="jml_in" id="jml_in" placeholder="Satuan Repack" />
                    <input readonly="" type="hidden" class="form-control" value="" name="id_repack_temp" id="id_repack_temp" placeholder="Satuan Repack" />
                  </div>
                  <div class="col-md-2">
                    <label>Konversi</label>
                    <input type="text" class="form-control" value="" name="konversi" id="konversi" placeholder="Konversi" />
                  </div>
                  <div class="col-md-2">
                    <label>Jumlah Repack</label>
                    <input type="text" class="form-control" value="" name="jumlah_repack" id="jumlah_repack" placeholder="Jumlah Repack" />
                  </div>
                  <div class="col-md-2">
                    <br>
                    <br>
                    <button type="button" id="add" class="btn btn-primary">Add</button>
                    <button type="button" id="update" class="btn btn-primary">Update</button>
                  </div>
                </div>
              </div>  

              <div class="col-md-12"><br><br>
                <table class="table table-striped table-hover table-bordered" id="sample_editable_1"  style="font-size:1.5em;">
                  <thead>
                    <tr>
                      <th width="5%">No</th>
                      <th>Produk</th>
                      <th>Produk Repack</th>
                      <th>Jumlah Repack</th>
                      <th>Action</th> 

                    </tr>
                  </thead>
                  <tbody id="tabel_temp_data">

                  </tbody>                
                </table>

                <button type="submit" id="simpan" class="btn btn-primary pull-right">Simpan</button>
                <button type="button" id="batal" class="btn btn-danger pull-right">Batal</button>
              </div>
            </form>
          </div>

        </div>
      </div>

      <!------------------------------------------------------------------------------------------------------>
    </div>
  </div>
</div>
<div id="modal_delete_temp" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color:grey">

        <h4 class="modal-title" style="color:#fff;">Konfirmasi Hapus</h4>
      </div>
      <div class="modal-body">
        <span style="font-weight:bold; font-size:14pt">Apakah anda yakin akan Menghapus Data Ini?</span>
        <input id="id-delete" type="hidden">
      </div>
      <div class="modal-footer" style="background-color:#eee">
        <button class="btn red" data-dismiss="modal" aria-hidden="true">Tidak</button>
        <button onclick="delete_data()" class="btn green">Ya</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function() {
    $('.select2').select2();
    $('#update').hide();
  });

  function get_temp(){
    kode_repack = $('#kode').val();
    $("#tabel_temp_data").load('<?php echo base_url().'repack/get_repack_temp/'; ?>'+kode_repack);
  }
  function get_jumlah_dalam_satuan_pembelian(){
    produk_repack = $('#produk_repack').val();
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/get_satuan' ?>",  
      cache :false,
      dataType : 'json',
      data :({repack:produk_repack}),
      success : function(data) {  
        $('#sat_repack').val(data.satuan_stok);
        $('#jumlah_dalam_satuan_pembelian').val(data.jumlah_dalam_satuan_pembelian);
        $('#konversi').val(Math.round(($('#jml_in').val()*$('#jumlah_dalam_satuan_pembelian').val())/$('#jumlah_repack').val()));
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
  }
  function actEdit(id){
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/get_edit_data' ?>",  
      cache :false,
      dataType : 'json',
      data :({key:id}),
      success : function(data) {
        $("#produk").select2().select2('val', data.kode_bahan);
        $("#produk_repack").select2().select2('val', data.kode_produk_repack);
        get_jumlah_dalam_satuan_pembelian();
        $('#jml_in').val(data.jumlah_in);
        $('#jumlah_repack').val(data.jumlah);
        $('#id_repack_temp').val(data.id);
        $('#add').hide();
        $('#update').show();
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
  }
  function actDelete(id){
    $('#id-delete').val(id);
    $("#modal_delete_temp").modal('show');
  }
  function delete_data(){
    id = $('#id-delete').val();
    $("#modal_delete_temp").modal('hide');
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/hapus_repack_temp' ?>",  
      cache :false,
      data :({key:id}),
      success : function(data) {  
        get_temp();
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
  }

  $('#produk_repack').change(function() {
    produk_repack = $('#produk_repack').val();
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/get_satuan' ?>",  
      cache :false,
      dataType : 'json',
      data :({repack:produk_repack}),
      success : function(data) {  
        $('#sat_repack').val(data.satuan_stok);
        $('#jumlah_dalam_satuan_pembelian').val(data.jumlah_dalam_satuan_pembelian);
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
  });
  $('#add').click(function() {
    kode_repack = $('#kode').val();
    produk = $('#produk').val();
    produk_repack = $('#produk_repack').val();
    jumlah_satuan = $('#jumlah_dalam_satuan_pembelian').val();
    konversi = $('#konversi').val();
    jml_repack = $('#jumlah_repack').val();
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/add_repack_temp' ?>",  
      cache :false,
      data :({kode_repack:kode_repack, produk:produk, produk_repack:produk_repack, jumlah_satuan:jumlah_satuan, konversi:konversi, jml_repack:jml_repack}),
      success : function(data) {
        if(data.length < 10){
          $("#produk").select2().select2('val','');
          $("#produk_repack").select2().select2('val','');
          $('#sat_repack').val('');
          $('#jumlah_dalam_satuan_pembelian').val('');
          $('#konversi').val('');
          $('#jumlah_repack').val('');
        }else{
          $('.cek_stok').html(data);
          setTimeout(function(){$('.cek_stok').html('');},1500);
        }
        get_temp();
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
  });
  $('#update').click(function() {
    kode_repack = $('#kode').val();
    id_repack_temp = $('#id_repack_temp').val();
    produk = $('#produk').val();
    produk_repack = $('#produk_repack').val();
    jumlah_satuan = $('#jumlah_dalam_satuan_pembelian').val();
    konversi = $('#konversi').val();
    jml_repack = $('#jumlah_repack').val();
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/update_repack_temp' ?>",  
      cache :false,
      data :({kode_repack:kode_repack, produk:produk, id_repack_temp:id_repack_temp, produk_repack:produk_repack, jumlah_satuan:jumlah_satuan, konversi:konversi, jml_repack:jml_repack}),
      success : function(data) {  
        if(data.length < 10){
          $("#produk").select2().select2('val','');
          $("#produk_repack").select2().select2('val','');
          $('#sat_repack').val('');
          $('#jumlah_dalam_satuan_pembelian').val('');
          $('#konversi').val('');
          $('#jumlah_repack').val('');
          $('#id_repack_temp').val('');
          $('#add').show();
          $('#update').hide();
        }else{
          $('.cek_stok').html(data);
          setTimeout(function(){$('.cek_stok').html('');},1500);
        }
        get_temp();
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
  });
  $('#form_repack').submit(function() {
    $.ajax( {  
      type :"post",  
      url : "<?php echo base_url() . 'repack/simpan_repack' ?>",  
      cache :false,
      data :$(this).serialize(),
      success : function(data) {  
        $(".sukses").html(data);   
        setTimeout(function(){$('.sukses').html('');window.location = "<?php echo base_url() . 'repack/daftar' ?>";},1500);              
      },  
      error : function() {  
        alert("Data gagal dimasukkan.");  
      }  
    });
    return false;
  });
  $('#batal').click(function() {
    window.location = "<?php echo base_url() . 'repack/menu' ?>";
  });
</script>
