      
<?php


$param = $this->input->post();
              // $kode = $this->input->post('kode_transaksi');

            // if(@$param['tgl_awal'] && @$param['tgl_akhir'] && @$param['nama']){
            //   $nama = $param['nama'];
            //   $tgl_awal = $param['tgl_awal'];
            //   $tgl_akhir = $param['tgl_akhir'];
            // $this->db->where('nama', $nama);
            // $this->db->where('tanggal_order >=', $tgl_awal);
            // $this->db->where('tanggal_order <=', $tgl_akhir);
            // }

if(@$param['filter'] && @$param['opsi_filter']){

  $filter = $param['filter'];
  $opsi_filter = $param['opsi_filter'];
  $kode_unit = $param['kode_unit'];

  if($filter == "kategori"){
    $this->db->where('kode_kategori_produk =', $opsi_filter);
  } else if($filter == "blok"){
    $this->db->where('kode_rak =', $opsi_filter);
  }
  $this->db->where('kode_unit =', $kode_unit);

}
$this->db->select('*');
$this->db->from('master_bahan_baku');
$transaksi = $this->db->get();
$hasil_transaksi = $transaksi->result();

$total=0;
$kode_default = $this->db->get('setting_gudang');
$hasil_unit =$kode_default->row();
$param =$hasil_unit->kode_unit;
?>
<br>
<br>
<br>
<form method="post" id="opsi_spoil"> 
  <table class="table table-striped table-hover table-bordered" id="tabel_daftar" style="font-size:1.5em;">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Jumlah</th>
        <th>Nama Blok</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php

      $nomor = 1;  

      foreach($hasil_transaksi as $daftar){ 
        ?> 
        <tr>
          <td><?php echo $nomor; ?></td>
          <td><?php echo $daftar->nama_bahan_baku; ?></td>
          <td><?php echo $daftar->real_stock.' '.$daftar->satuan_stok; ?></td>
          <td><?php echo $daftar->nama_rak; ?></td>
          <td align="center"><input name="opsi_spoil[]" type="checkbox" id="opsi_pilihan" value="<?php echo $daftar->kode_bahan_baku; ?>"></td>
        </tr>
        <?php 
        $nomor++; 
      } 
      ?>

    </tbody>
    <tfoot>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Jumlah</th>
        <th>Nama Blok</th>
        <th>Action</th>
      </tr>
    </tfoot>            
  </table>
  <input type="hidden" name="kode_unit" id="kode_unit" value="<?php echo $param ?>">
  <?php
  $tgl = date("Y-m-d");
  $no_belakang = 0;
  $this->db->select_max('kode_spoil');
  $kode = $this->db->get_where('transaksi_spoil',array('tanggal_spoil'=>$tgl));
  $hasil_kode = $kode->row();
  $this->db->select('kode_spoil');
  $kode_spoil = $this->db->get('master_setting');
  $hasil_kode_spoil = $kode_spoil->row();

  if(count($hasil_kode)==0){
    $no_belakang = 1;
  }
  else{
    $pecah_kode = explode("_",$hasil_kode->kode_spoil);
    $no_belakang = @$pecah_kode[2]+1;
  }
  ?>
  <input type="hidden" name="kode_spoil" id="kode_spoil" value="<?php echo @$hasil_kode_spoil->kode_spoil."_".date("dmyHis")."_".$no_belakang ?>">
</form>