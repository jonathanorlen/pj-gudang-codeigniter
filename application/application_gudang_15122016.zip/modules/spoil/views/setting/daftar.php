
<div class="row">      
  <div class="col-xs-12">
    <!-- /.box -->
    <div class="portlet box blue">
      <div class="portlet-title">
        <div class="caption">
          Spoil
        </div>
        <div class="tools">
          <a href="javascript:;" class="collapse">
          </a>
          <a href="javascript:;" class="reload">
          </a>

        </div>
      </div>
      <div class="portlet-body">

        <!------------------------------------------------------------------------------------------------------>

        <div class="row"> 

          <div class="col-md-12">

            <!-- <a style="padding:13px; margin-bottom:10px;" class="btn btn-app green" href="<?php echo base_url().'spoil/tambah_spoil/'; ?>"><i class="fa fa-edit"></i> Tambah </a> -->

            <div class="box-body">            
              <div class="sukses" ></div>
              <div class="col-md-10 row" id="">
                <div class="col-md-5 row" id="">
                  <div class="input-group">
                    <span class="input-group-addon">Filter</span>
                    <select class="form-control" id="filter">
                      <option value="">- PILIH -</option>
                      <option value="kategori">Kategori Produk</option>
                      <option value="blok">Blok</option>
                    </select>
                  </div>
                  <br>
                </div>
              </div>
              
              <div class="col-md-10 row" id="opsi_filter">
                <div class="col-md-5 row" id="">
                  <div class="input-group">
                    <span class="input-group-addon" id="nama_input_opsi"></span>
                    <select class="form-control" id="option_opsi_filter">
                      <option value="">- PILIH -</option>
                      <option value="kategori">Kategori Produk</option>
                      <option value="blok">Blok</option>
                    </select>
                  </div>
                  <br>
                </div>                        
              </div>                        
              <div class="col-md-10 row" id="">
                <div class="col-md-5 row" id="">
                  <button style="width: 148px" type="button" class="btn btn-warning pull-right" id="cari"><i class="fa fa-search"></i> Cari</button>
                </div>
              </div>  
              <br><br>
              <div class="col-md-12 row" id="cari_transaksi">
                <form method="post" id="opsi_spoil"> 
                  <table class="table table-striped table-hover table-bordered" id="tabel_daftar" style="font-size:1.5em;">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Jumlah</th>
                        <th>Nama Blok</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $kode_default = $this->db->get('setting_gudang');
                      $hasil_unit =$kode_default->row();
                      $param =$hasil_unit->kode_unit;
                      $spoil = $this->db->get_where('master_bahan_baku',array('kode_unit' => $param));
                      $list_spoil = $spoil->result();
                      $nomor = 1;  
                      
                      foreach($list_spoil as $daftar){ 
                        ?> 
                        <tr>
                          <td><?php echo $nomor; ?></td>
                          <td><?php echo $daftar->nama_bahan_baku; ?></td>
                          <td><?php echo $daftar->real_stock.' '.$daftar->satuan_stok; ?></td>
                          <td><?php echo $daftar->nama_rak; ?></td>
                          <td align="center"><input name="opsi_spoil[]" type="checkbox"  id="opsi_pilihan" value="<?php echo $daftar->kode_bahan_baku; ?>"></td>
                        </tr>
                        <?php 
                        $nomor++; 
                      } 
                      ?>

                    </tbody>
                    <tfoot>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Jumlah</th>
                        <th>Nama Blok</th>
                        <th>Action</th>
                      </tr>
                    </tfoot>            
                  </table>
                  <input type="hidden" name="kode_unit" id="kode_unit" value="<?php echo $param ?>">
                  <?php
                  $tgl = date("Y-m-d");
                  $no_belakang = 0;
                  $this->db->select_max('kode_spoil');
                  $kode = $this->db->get_where('transaksi_spoil',array('tanggal_spoil'=>$tgl));
                  $hasil_kode = $kode->row();
                  $this->db->select('kode_spoil');
                  $kode_spoil = $this->db->get('master_setting');
                  $hasil_kode_spoil = $kode_spoil->row();

                  if(count($hasil_kode)==0){
                    $no_belakang = 1;
                  }
                  else{
                    $pecah_kode = explode("_",$hasil_kode->kode_spoil);
                    $no_belakang = @$pecah_kode[2]+1;
                  }
                  ?>
                  <input type="hidden" name="kode_spoil" id="kode_spoil" value="<?php echo @$hasil_kode_spoil->kode_spoil."_".date("dmyHis")."_".$no_belakang ?>">
                </form>
              </div>
              <div class="row" id="">
                <a style="padding:13px; margin-bottom:10px; margin-right:45px;" id="spoil_tambah" class="btn btn-app green pull-right" ><i class="fa fa-edit"></i> Spoil </a>
                <!-- <button type="button" class="btn btn-success btn-block pull-right" id="spoil_tambah"><font size="6"><b>SPOIL</b></font></button> -->
              </div>  
            </div>
          </div>
          <!------------------------------------------------------------------------------------------------------>

        </div>
      </div>
    </div><!-- /.col -->
  </div>
</div>    
<div id="modal-confirm" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color:grey">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title" style="color:#fff;">Konfirmasi Hapus Data</h4>
      </div>
      <div class="modal-body">
        <span style="font-weight:bold; font-size:14pt">Apakah anda yakin akan menghapus data menu tersebut ?</span>
        <input id="id-delete" type="hidden">
      </div>
      <div class="modal-footer" style="background-color:#eee">
        <button class="btn green" data-dismiss="modal" aria-hidden="true">Tidak</button>
        <button onclick="delData()" class="btn red">Ya</button>
      </div>
    </div>
  </div>
</div>

<script src="<?php echo base_url().'component/lib/jquery.min.js'?>"></script>
<script src="<?php echo base_url().'component/lib/zebra_datepicker.js'?>"></script>
<link rel="stylesheet" href="<?php echo base_url().'component/lib/css/default.css'?>"/>
<script type="text/javascript">
  $('#filter').change(function(){
    filter = $('#filter').val();
    if(filter != ""){
      $("#opsi_filter").show();
      $.ajax( {  
        type :"post",  
        url : "<?php echo base_url().'spoil/get_opsi_filter'; ?>",  
        cache :false,
        data : {filter:filter},
        beforeSend:function(){
          $(".tunggu").show();  
        },
        success : function(data) {
          $(".tunggu").hide();  
          $("#option_opsi_filter").html(data);
          if(filter == "kategori"){
            $("#nama_input_opsi").html("Kategori Produk");
          } else if(filter == "blok"){
            $("#nama_input_opsi").html("Blok");
          }
        },  
        error : function(data) {
        }  
      });
    } else {
      $("#opsi_filter").hide();
    }
  });

  $('.tgl').Zebra_DatePicker({});

  $('#spoil_tambah').click(function(){
    checkedValue = $('#opsi_pilihan:checked').val();
    kode_spoil = $('#kode_spoil').val();
    if(!checkedValue){
      alert("Pilih Barang Yang Akan Di Spoil");
    } else {
      $.ajax( {  
        type :"post",  
        url : "<?php echo base_url().'spoil/simpan_spoil_temp_baru'; ?>",  
        cache :false,
        data : $("#opsi_spoil").serialize(),
        beforeSend:function(){
          $(".tunggu").show();  
        },
        success : function(data) {
          $(".tunggu").hide();  
          setTimeout(function(){
            window.location = "<?php echo base_url() . 'spoil/tambah_spoil/'; ?>"+kode_spoil;
          },15);       
        },  
        error : function(data) {
        }  
      });
    }

  });

  $('#cari').click(function(){

    filter = $('#filter').val();
    opsi_filter = $('#option_opsi_filter').val();
    kode_unit =$("#kode_unit").val();
    if (filter=='' || filter==''){ 
      alert('Masukan Fiter & Kategori Produk atau blok..!')
    }
    else{
      $.ajax( {  
        type :"post",  
        url : "<?php echo base_url().'spoil/cari_produk'; ?>",  
        cache :false,
        data : {filter:filter,opsi_filter:opsi_filter,kode_unit:kode_unit},
        beforeSend:function(){
          $(".tunggu").show();  
        },
        success : function(data) {
          $(".tunggu").hide();  
          $("#cari_transaksi").html(data);

          $("#opsi_filter").hide();
        },  
        error : function(data) {
        }  
      });
    }

    $('#filter').val('');
    $('#option_opsi_filter').val('');

  });

</script>
<script>
  $(document).ready(function(){

    $("#opsi_filter").hide();

    $("#tabel_daftar").dataTable({
      "paging":   false,
      "ordering": true,
      "info":     false
    });
  })

  function actDelete(Object) {
    $('#id-delete').val(Object);
    $('#modal-confirm').modal('show');
  }

  function delData() {
    var id = $('#id-delete').val();
    var url = '<?php echo base_url().'master/menu_resto/hapus_bahan_jadi'; ?>/delete';
    $.ajax({
      type: "POST",
      url: url,
      data: {
        id: id
      },
      beforeSend:function(){
        $(".tunggu").show();  
      },
      success: function(msg) {
        $('#modal-confirm').modal('hide');
        window.location.reload();
      }
    });
    return false;
  }

</script>
