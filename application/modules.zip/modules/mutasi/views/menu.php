<div class="">
	<div class="page-content">

		<div class="box-footer clearfix">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a class="dashboard-stat dashboard-stat-light blue-soft" id="daftar_cooling" href="<?php echo base_url().'stok/daftar_stok'?>">
						<div class="visual">
							<i class="glyphicon glyphicon-taskss" >></i>
						</div>
						<div class="details" >
							<div class="number">
								
							</div>
							<div class="desc">
								Stok
							</div>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a class="dashboard-stat dashboard-stat-light red-soft" href="<?php echo base_url().'spoil/daftar_spoil'?>" id="daftar_pos">
						<div class="visual">
							<i class="glyphicon glyphicon-shopping-cart"></i>
						</div>
						<div class="details">
							<div class="number">
								
							</div>
							<div class="desc">
								Spoil
							</div>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a class="dashboard-stat dashboard-stat-light green-soft" href="<?php echo base_url().'opname/daftar_opname' ?>" id="daftar_kelompok">
						<div class="visual">
							<i class="glyphicon glyphicon-th" ></i>
						</div>
						<div class="details">
							<div class="number">
								
							</div>
							<div class="desc">
								Opname
							</div>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a class="dashboard-stat dashboard-stat-light purple-soft" href="<?php echo base_url().'mutasi/daftar_mutasi' ?>" id="daftar_jenis">
						<div class="visual">
							<i class="glyphicon glyphicon-user" ></i>
						</div>
						<div class="details">
							<div class="number">
								
							</div>
							<div class="desc">
								Mutasi
							</div>
						</div>
					</a>
				</div>

			</div>
			<!-- <a style="padding:13px; margin-bottom:10px;" class="btn btn-app green" href="<?php echo base_url() . 'mutasi/tambah_mutasi' ?>"><i class="fa fa-edit"></i> Tambah </a>
			<a style="padding:13px; margin-bottom:10px;" class="btn btn-app blue" href="<?php echo base_url() . 'mutasi/daftar_mutasi' ?>"><i class="fa fa-list"></i> Daftar </a> -->
		</div>


		<div id="box_load">
			<?php echo @$konten; ?>
		</div>
	</div>
</div>
