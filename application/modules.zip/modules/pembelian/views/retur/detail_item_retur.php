
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Data Retur Pembelian </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin').'/dasboard' ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      </ol>
    </section>
<style type="text/css">
 .ombo{
  width: 600px;
 } 

</style>    
    <!-- Main content -->
    <section class="content">             
      <!-- Main row -->
      
        <div class="row">
        <!-- Left col -->
            <section class="col-lg-12 connectedSortable">
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app green" href="<?php echo base_url().'pembelian/pembelian/tambah'; ?>">
              <i class="fa fa-plus"></i> Tambah Pembelian
            </a>
            
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app blue" href="<?php echo base_url().'pembelian/pembelian/daftar_pembelian'; ?>">
              <i class="fa fa-list"></i> Daftar Pembelian
            </a>
            
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app green" href="<?php echo base_url().'pembelian/retur/tambah'; ?>">
              <i class="fa fa-plus"></i> Tambah Retur Pembelian
            </a>
            
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app blue" href="<?php echo base_url().'pembelian/retur/daftar_retur_pembelian'; ?>">
              <i class="fa fa-list"></i> Daftar Retur Pembelian
            </a>

            <a style="padding:13px; margin-bottom:10px" class="btn btn-app green" href="<?php echo base_url().'pembelian/po/tambah'; ?>">
              <i class="fa fa-plus"></i> Formulir PO
            </a>
            
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app blue" href="<?php echo base_url().'pembelian/po/daftar_po'; ?>">
              <i class="fa fa-list"></i> Daftar PO
            </a>

                <div class="box box-info">
                  <div class="box-header">
                      <!-- tools box -->
                      <div class="pull-right box-tools"></div><!-- /. tools -->
                  </div>
                        
                      <form id="data_form" action="" method="post">
                        
                        <div class="box-body">
                        <div id="list_retur_pembelian">
                          <div class="box-body">
                          <table id="tabel_daftar" class="table table-bordered table-striped">
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Nama bahan</th>
                                <th>QTY</th>
                                <th>Harga Satuan</th>
                                <th>Subtotal</th>
                              </tr>
                            </thead>
                            <tbody id="tabel_temp_data_retur">            
                                <?php
                                    if($kode){
                                      $opsi_pembelian = $this->db->get_where('opsi_transaksi_retur',array('kode_retur'=>$kode));
                                      $list_opsi_pembelian = $opsi_pembelian->result();
                                      $nomor = 1;  $total = 0;
                                      foreach($list_opsi_pembelian as $daftar){ 
                                ?>
                                <tr>
                                    <td><?php echo $nomor; ?></td>
                                    <td><?php echo $daftar->nama_bahan; ?></td>
                                    <td><?php echo $daftar->jumlah; ?></td>
                                    <td><?php echo $daftar->harga_satuan; ?></td>
                                    <td><?php echo $daftar->subtotal; ?></td>
                                </tr>
                                <?php 
                                        @$total = $total + $daftar->subtotal;
                                        $nomor++; 
                                      } 
                                  }
                                  else{
                                ?>
                                <tr>
                                    <td><?php echo @$nomor; ?></td>
                                    <td><?php echo @$daftar->nama_bahan; ?></td>
                                    <td><?php echo @$daftar->jumlah; ?></td>
                                    <td><?php echo @$daftar->harga_satuan; ?></td>
                                    <td><?php echo @$daftar->subtotal; ?></td>
                                </tr>
                                <?php
                                  }
                                ?>
                                
                                <tr>
                                  <td colspan="3"></td>
                                  <td style="font-weight:bold;">Total</td>
                                  <td><?php echo @$total; ?></td>
                                </tr>

                                <tr>
                                  <td colspan="3"></td>
                                  <td style="font-weight:bold;">Grand Total</td>
                                  <td><?php echo @$total; ?></td>
                                </tr>
                            </tbody>
                            <tfoot>
                            </tfoot>

                          </table>
                          </div>
                        </div>

                        <div class="box-body">
                          <div class="row">
                            <div class="col-md-12">
                                <?php 
                                    $pembelian = $this->db->get_where('transaksi_retur',array('kode_retur'=>$kode));
                                    $list_pembelian = $pembelian->row();
                                ?>
                                <label>Keterangan</label>
                                <input class="form-control" value="<?php echo @$list_pembelian->keterangan; ?>" readonly >
                            </div>
                          </div>
                      </div>
                    </div>

                      </form>
                      </div>        
                    </div>  

                      
                </div>
            </section><!-- /.Left col -->      
        </div><!-- /.row (main row) -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

